import * as moduleControl from "../module/produitControl.mjs";

moduleControl.initproduit();
