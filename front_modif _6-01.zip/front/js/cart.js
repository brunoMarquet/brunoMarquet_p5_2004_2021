import * as moduleControl from "../module/cartControl.mjs";

moduleControl.initCart();
